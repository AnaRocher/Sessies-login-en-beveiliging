<?php

session_start();

$pdo = new PDO('mysql:host=localhost;dbname=gastenboek_login;port=8889', 'root', 'root');